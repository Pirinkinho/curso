function saludar() {
    console.log("Hola desde archivo1.js!");
}
saludar();
