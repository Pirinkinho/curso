import fizzBuzz from './fizzbuzz';
import mapWithCb from './mapWithCb';
import getPokemon from './getPokemon';

export {
  fizzBuzz,
  mapWithCb,
  getPokemon
};
