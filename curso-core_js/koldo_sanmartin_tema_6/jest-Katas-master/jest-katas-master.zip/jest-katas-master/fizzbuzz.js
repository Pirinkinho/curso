export const fizzBuzz = () => {
  return;
};
