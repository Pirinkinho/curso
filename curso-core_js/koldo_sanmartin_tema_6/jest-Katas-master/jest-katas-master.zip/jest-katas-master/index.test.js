import nock from 'nock';
import { fizzBuzz, mapWithCb, getPokemon } from '.';

describe('1. fizzBuzz', () => {

});

describe('2. mapWithCb', () => {
  it('throws an error if first argument is not an array', () => {

  });
  
  it('throws an error if second argument is not a function', () => {

  });
  
  it('calls the given function at least once', () => {

  });

  it('calls the given function a number of times equal to the length of the given array', () => {

  });

  it('calls the given function with any one item from the given array', () => {

  });

  it('calls the given function a second time with the second item in the given array', () => {

  });

  it('calls the given function a final time with the final item in the given array', () => {

  });
})

describe('3. getPokemon', () => {

});
