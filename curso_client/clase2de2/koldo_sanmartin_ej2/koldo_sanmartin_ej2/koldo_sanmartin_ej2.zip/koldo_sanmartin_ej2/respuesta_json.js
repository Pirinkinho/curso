{
    "coord": {
    "lon": 0,
    "lat": 0
    },
    "weather": [
    {
    "id": 804,
    "main": "Clouds",
    "description": "nubes",
    "icon": "04n"
    }
    ],
    "base": "stations",
    "main": {
    "temp": 299.59,
    "feels_like": 299.59,
    "temp_min": 299.59,
    "temp_max": 299.59,
    "pressure": 1012,
    "humidity": 78,
    "sea_level": 1012,
    "grnd_level": 1012
    },
    "visibility": 10000,
    "wind": {
    "speed": 5.85,
    "deg": 177,
    "gust": 5.31
    },"clouds": {
    "all": 100
    },
    "dt": 1673460850,
    "sys": {
    "sunrise": 1673417038,
    "sunset": 1673460667
    },
    "timezone": 0,
    "id": 6295630,
    "name": "Globe",
    "cod": 200
    }