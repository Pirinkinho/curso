// alert.js
function clickMe() {
  alert("Ejemplo de estático javascript");
}
